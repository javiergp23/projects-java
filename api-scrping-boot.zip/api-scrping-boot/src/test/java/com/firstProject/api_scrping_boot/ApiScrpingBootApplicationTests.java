package com.firstProject.api_scrping_boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiScrpingBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
